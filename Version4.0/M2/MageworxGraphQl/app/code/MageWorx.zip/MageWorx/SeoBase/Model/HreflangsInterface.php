<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\SeoBase\Model;

/**
 * @api
 */
interface HreflangsInterface
{
    public function getHreflangUrls();
}

<?php
/**
 * Copyright © 2017 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\SeoXTemplates\Model;

use Magento\Framework\ObjectManagerInterface as ObjectManager;

/**
 * Factory class
 * @see \MageWorx\SeoXTemplates\Model\Converter
 */
class ConverterCategoryFilterFactory extends \MageWorx\SeoXTemplates\Model\ConverterCategoryFactory
{

}
